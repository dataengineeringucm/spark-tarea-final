﻿from pyspark.sql import DataFrame as DF, SparkSession, functions as F


class MotorIngesta:
    """Motor de ingesta de archivos JSON para Spark."""

    def __init__(self, config: dict):
        """Inicializa el motor con la configuracion de columnas."""
        self.config = config
        self.spark = SparkSession.builder.getOrCreate()

    def ingesta_fichero(self, json_path: str) -> DF:
        """Carga un JSON y devuelve un DataFrame aplanado segun configuracion."""
        flights_day_df = self.spark.read.option("inferSchema", "true").json(json_path)
        aplanado_df = MotorIngesta.aplana_df(flights_day_df)

        lista_obj_column = [
            F.col(col_cfg["name"]).cast(col_cfg["type"]).alias(
                col_cfg["name"], metadata={"comment": col_cfg["comment"]}
            )
            for col_cfg in self.config["data_columns"]
        ]

        return aplanado_df.select(*lista_obj_column)

    @staticmethod
    def aplana_df(df: DF) -> DF:
        """Aplana arrays y structs de un DataFrame de Spark de forma recursiva."""
        to_select = []
        recurse = False

        for field in df.schema.jsonValue()["fields"]:
            if not isinstance(field["type"], dict):
                to_select.append(field["name"])
            elif field["type"]["type"] == "array":
                to_select.append(F.explode(field["name"]).alias(field["name"]))
                recurse = True
            elif field["type"]["type"] == "struct":
                to_select.append(f"{field['name']}.*")
                recurse = True

        new_df = df.select(*to_select)
        return MotorIngesta.aplana_df(new_df) if recurse else new_df
