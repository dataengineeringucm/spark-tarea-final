﻿import json
from datetime import timedelta
from pathlib import Path

from loguru import logger
from pyspark.sql import SparkSession, functions as F

from .agregaciones import aniade_hora_utc, aniade_intervalos_por_aeropuerto
from .motor_ingesta import MotorIngesta


class FlujoDiario:
    """Orquestador del procesamiento diario de vuelos."""

    def __init__(self, config_file: str):
        """Inicializa configuracion, sesion Spark y recursos internos."""
        with open(config_file, "r", encoding="utf-8") as f:
            self.config = json.load(f)

        if self.config["EXECUTION_ENVIRONMENT"] == "databricks":
            # Import condicional para no exigir databricks-connect en modo local.
            from databricks.connect import DatabricksSession

            self.spark = DatabricksSession.builder.getOrCreate()
        else:
            self.spark = SparkSession.builder.getOrCreate()

        # Recurso interno del paquete: no se toma de config externa.
        timezones_path = Path(__file__).resolve().parent / "resources" / "timezones.csv"
        self.timezones_df = (
            self.spark.read.option("header", "true")
            .option("inferSchema", "true")
            .csv(str(timezones_path))
            .cache()
        )

    def procesa_diario(self, data_file: str):
        """Procesa un lote diario completo y persiste salida en tabla manejada."""
        try:
            motor_ingesta = MotorIngesta(self.config)
            flights_df = motor_ingesta.ingesta_fichero(data_file).cache()

            # Paso 1. Anadir la hora de salida UTC.
            flights_with_utc = aniade_hora_utc(self.spark, flights_df, self.timezones_df)

            # Paso 2. Leer, si existe, la particion del dia anterior para cubrir intervalos entre dias.
            dia_actual = flights_df.first().FlightDate
            dia_previo = dia_actual - timedelta(days=1)
            try:
                flights_previo = self.spark.read.table(self.config["output_table"]).where(
                    F.col("FlightDate") == dia_previo
                )
                logger.info(f"Leida particion del dia {dia_previo} con exito")
            except Exception as e:
                logger.info(f"No se han podido leer datos del dia {dia_previo}: {str(e)}")
                flights_previo = None

            if flights_previo is not None:
                flights_with_utc_extended = (
                    flights_with_utc.withColumn("FlightTime_next", F.lit(None).cast("timestamp"))
                    .withColumn("Airline_next", F.lit(None).cast("string"))
                    .withColumn("diff_next", F.lit(None).cast("bigint"))
                )

                df_unido = flights_previo.select(flights_previo.columns).unionByName(
                    flights_with_utc_extended
                )

                # Spark no permite escribir en la misma tabla que se esta leyendo.
                df_unido.write.mode("overwrite").saveAsTable("tabla_provisional")
                df_unido = self.spark.read.table("tabla_provisional")
            else:
                df_unido = flights_with_utc

            # Paso 3. Anadir informacion del vuelo siguiente.
            df_with_next_flight = aniade_intervalos_por_aeropuerto(df_unido)

            # Paso 4. Escribir en tabla manejada particionada por FlightDate.
            (
                df_with_next_flight.coalesce(self.config["output_partitions"])
                .write.mode("overwrite")
                .option("partitionOverwriteMode", "dynamic")
                .partitionBy("FlightDate")
                .saveAsTable(self.config["output_table"])
            )

            self.spark.sql("DROP TABLE IF EXISTS tabla_provisional")

        except Exception as e:
            logger.error(f"No se pudo escribir la tabla del fichero {data_file}")
            raise e


if __name__ == "__main__":
    # Ejemplo de uso local.
    flujo = FlujoDiario("config/config.json")
    flujo.procesa_diario("ruta/al/archivo.json")
